<?php
include("Classes/Generals.php");
$SessionCheck = new Generals();
$SessionCheck->PublicPagesSessionCheck();
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #AlpacaPicTable {
            margin:auto;
            width:90%;
            border-collapse:collapse;
        }
        #AlpacaPicHeader {
            background-color:rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .AlpacaPicMeta {
            background-color:rgba(173, 128, 84, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .AlpacaPicCont {
            background-color:rgba(255, 255, 255, 0.9);
            text-align:center;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <br />
            <table id="AlpacaPicTable">
                <tr>
                    <th id="AlpacaPicHeader">
                        Flotte Alpaca Billeder
                    </th>
                </tr>
                <tr>
                    <td class="AlpacaPicMeta">
                        Alpaca billede 1
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicCont">
                        <img width="850" height="525" src="Billeder/Alpaca01.jpg" />
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicMeta">
                        Alpaca billede 2
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicCont">
                        <img width="850" height="655" src="Billeder/Alpaca02.jpg" />
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicMeta">
                        Alpaca billede 3
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicCont">
                        <img width="850" height="515" src="Billeder/Alpaca03.jpg" />
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicMeta">
                        Alpaca billede 4
                    </td>
                </tr>
                <tr>
                    <td class="AlpacaPicCont">
                       <img width="850" height="530" src="Billeder/Alpaca04.jpg" />
                    </td>
                </tr>
            </table>
            <br />
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>

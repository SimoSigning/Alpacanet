<?php 
        include("Classes/Generals.php");
        include("Classes/DataConnector.php");
        include("Classes/DataBindings.php");
        
        $SessionCheck = new Generals();
        $SessionCheck ->LoginPagesSessionCheck();
        
        $BrugerID = $_SESSION["BrugerID"];
        
        function SelectCurrentUser($BrugerID) {
            $connector = new DataConnector("localhost", "root", "", "alpacadb");
            $RedigerKols = array("Password", "Email", "Fornavn", "Efternavn", "Telefon");
            $redigerProfileView = new DataBindings("brugere");
            $redigerProfileView->SetKols($RedigerKols);
            $redigerProfileView->SetJoin("profiler", "profiler.BrugerID", "brugere.Id");
            $redigerProfileView->SetCon("Id", $BrugerID);
            $GetUserResult = $redigerProfileView->SelectFromInnerJoinWhere($connector->CreateCon());
            $RowUserResult = mysqli_fetch_assoc($GetUserResult);
            $connector->DisableCon();
            return $RowUserResult;
        }
        if(!isset($_POST['RedigerSub']))
        {
            $RowUserResult = SelectCurrentUser($BrugerID);
        }
        else if(isset($_POST['RedigerSub'])) 
        {
            //Modtagelse af data
            $Password = $_POST['Password'];
            $Email = $_POST['Email'];
            $Fornavn = $_POST['Fornavn'];
            $Efternavn = $_POST['Efternavn'];
            $Telefon = $_POST['Telefon'];
            
            //Bruger update data
            $BrugerKolArr = array("Password", "Email");
            $BrugerValArr = array($Password, $Email);
            $BrugerConKol = "Id";
            $BrugerConVal = $BrugerID;
            
            //Profil update data
            $ProfilKolArr = array("Fornavn", "Efternavn", "Telefon");
            $ProfilValArr = array($Fornavn, $Efternavn, $Telefon);
            $ProfilConKol = "BrugerID";
            $ProfilConVal = $BrugerID;
            
            //Instancier connection objekt
            $Connection = new DataConnector("localhost", "root", "", "alpacadb");
            
            //Opdater bruger
            $brugerUpdater = new DataBindings("brugere");
            $brugerUpdater->SetKols($BrugerKolArr);
            $brugerUpdater->SetVals($BrugerValArr);
            $brugerUpdater->SetCon($BrugerConKol, $BrugerConVal);
            $brugerUpdater->UpdateSetWhere($Connection->CreateCon());
            
            //Opdater profil
            $profilUpdater = new DataBindings("profiler");
            $profilUpdater->SetKols($ProfilKolArr);
            $profilUpdater->SetVals($ProfilValArr);
            $profilUpdater->SetCon($ProfilConKol, $ProfilConVal);
            $profilUpdater->UpdateSetWhere($Connection->CreateCon());
            
            $RowUserResult = SelectCurrentUser($BrugerID);
        }
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #RedigerTable {
            margin:auto;
            border-collapse: collapse;
            width:60%;
        }
        #RedigerHeader {
            background-color: rgba(120, 89, 58, 0.7);
            padding-top:5px;
            padding-bottom:5px;
        }
        .TableSpacer {
            background-color: rgba(255,255,255,0.7);
        }
        .RedigerContent {
            background-color: rgba(255,255,255,0.7);
            padding-left:40%;
        }
        #RedigerFooter {
            background-color: rgba(120, 89, 58, 0.7);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        #SubmitBtn {
            width:15%;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <form action="RedigerProfil.php" method="POST">
            <table id="RedigerTable">
                <tr>
                    <th id="RedigerHeader">
                        Rediger Profil
                    </th>
                </tr>
               <tr>
                    <td class="TableSpacer">
                    </td>
                </tr>
                <tr>
                    <td class="RedigerContent">
                        Kodeord <br />
                        <input type='text' name='Password' value='<?php echo $RowUserResult["Password"] ?>'/>
                    </td>
                </tr>
                <tr>
                    <td class="RedigerContent">
                        Email <br />
                        <input type='text' name='Email' value='<?php echo $RowUserResult["Email"] ?>'/>
                    </td>
                </tr>
                <tr>
                    <td class="RedigerContent">
                        Fornavn <br />
                        <input type='text' name='Fornavn' value='<?php echo $RowUserResult["Fornavn"] ?>'/>
                    </td>
                </tr>
                <tr>
                    <td class="RedigerContent">
                        Efternavn <br />
                        <input type='text' name='Efternavn' value='<?php echo $RowUserResult["Efternavn"] ?>' />
                    </td>
                </tr>
                <tr>
                    <td class="RedigerContent">
                        Telefon <br />
                        <input type='text' name='Telefon' value='<?php echo $RowUserResult["Telefon"] ?>' />
                    </td>
                </tr>
                <tr>
                    <td class="TableSpacer">
                    </td>
                </tr>
                <tr>
                    <td id="RedigerFooter">
                        <input id="SubmitBtn" type="submit" name="RedigerSub" value="Opdater" />
                    </td>
                </tr>
            </table>
            </form>
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
<?php
spl_autoload_register(function ($class_name) {
    include $class_name . '.php';
});

$Arr01 = array("Fornavn","Efternavn","Adresse","Telefon");
$Arr02 = array("Sigurd", "Mogensen", "Sigurdvej", "22334455");

$ConKol = array("Id", "Kage", "Dyr");
$ConVal = array("BrugerID", "Brunsvier", "kat");
$Operators = array("||", "&&", "");

$JoinTables = array("katte", "hunde", "fugle");
$JoinKols = array("katte.EjerID", "hunde.EjerID", "fugle.EjerID");
$TableKols = array("kage.Id", "kage.Id", "kage.Id");
$BrugerID = 1;
/*
$Multiskinke = array (
array("array01First", "array01Second", "array01Third"),
array("array02First", "array02Second", "array02Third"),
array("array03First", "array03Second", "array03Third")
);

//echo count($Multiskinke[0]);
  
//echo $Multiskinke[0][2];
for($i = 0; $i < count($Multiskinke); $i++) {
    for($u=0; $u < count($Multiskinke[$i]); $u++)
          {
			echo $Multiskinke[$i][$u];
          };
};
*/
      /*  $connector = new DataConnector("localhost", "root", "", "alpacadb");
        $UserListKol = array("Brugernavn");
        $userListView = new DataBindings("brugere");
        $userListView->SetKols($UserListKol);
        $UserListReturn = $userListView->SelectFrom($connector->CreateCon());
        $UserListRows = mysqli_fetch_all($UserListReturn);
        
     /*   $counter = 0
        foreach($UserListRows as $elefant => $giraf)
        {
            $smerp[$giraf] = $elefant;
            $counter++;
        }
        */
       // print_r($UserListRows);*/

//$connector = new DataConnector("localhost", "root", "", "alpacadb");
/*
$derp = array("Brunsvier" => "herp", "Studenterbroed" => "derp", "Spandauer" => "kerb");
//echo $derp["Brunsvier"];

$counter = 0;
foreach ($derp as $elefant => $giraf)
{
    $karlsmart[$counter] = $elefant;
    $counter++;
}

for($i=0; $i < count($karlsmart); $i++)
{
    echo $derp[$karlsmart[$i]];
    echo "<br>";
}*/
/*
$BrugernavnKols = array("Brugernavn");
$validateUser = new DataBindings("brugere");
$validateUser->SetKols($BrugernavnKols);
$validateUser->SetCon("Brugernavn", "alfeprinsen");
$ValidateUserReturn = $validateUser->SelectFromWhere($connector->CreateCon());
$merp = mysqli_fetch_assoc($ValidateUserReturn);
if($merp == "")
{
    echo "nothing";
}
else {
    echo $merp["Brugernavn"];
}*/
//echo $merp["Brugernavn"];
/*$counter = 0;
while($herp = mysqli_fetch_assoc($ValidateUserReturn))
{w
    $derp = $herp["Brugernavn"];
    echo $derp;
}*/

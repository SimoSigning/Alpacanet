<?php
class DataBindings {   
    private $Table;
    private $KolArr = array();
    private $ValArr = array();
    private $ConKol;
    private $ConVal;
    private $ConKolArr = array();
    private $ConValArr = array();
    private $ConOps = array();
    private $JoinTable;
    private $JoinKol;
    private $TableKol;
    private $JoinTables = array();
    private $JoinKols = array();
    private $TableKols = array();
    private $ErrorMsg;
    
    function __construct($Table) {
        $this->Table = $Table;
    }
    public function SetKols($Kol=array())
    {
        $this->KolArr = $Kol;
    }
    public function SetVals($Val=array()) 
    {
        $this->ValArr = $Val;
    }
    public function SetCon($ConKol, $ConVal) 
    {
        $this->ConKol = $ConKol;
        $this->ConVal = $ConVal;
    }
    public function SetCons($ConKol=array(), $ConVal=array(), $Ops=array())
    {
        $this->ConKolArr = $ConKol;
        $this->ConValArr = $ConVal;
        $this->ConOps = $Ops;
    }
    public function SetJoin($JoinTable, $JoinKol, $TableKol) {
        $this->JoinTable = $JoinTable;
        $this->JoinKol = $JoinKol;
        $this->TableKol = $TableKol;
    }
    public function SetJoins($JoinTables = array(), $JoinKols = array(), $TableKols = array()) {
        $this->JoinTables = $JoinTables;
        $this->JoinKols = $JoinKols;
        $this->TableKols = $TableKols;
    }
    private function ValidateArrLengts($Arr01 = array(), $Arr02 = array()) 
    {
        if(count($Arr01) == count($Arr02))
        {
            return true;
        }
        else 
        {
            return false;
        }
    }
    
    private function KolValLoop($Structor, $Concat01, $Concat02, $Concat03, $Concat04, $Arr01 = array())
    {
        for($i = 0; $i < count($Arr01); $i++)
        {
            if($i < count($Arr01) - 1)
            {
                $Structor = $Structor . $Concat01 . $Arr01[$i] . $Concat02;
            }
            else 
            {
                $Structor = $Structor . $Concat03 . $Arr01[$i] . $Concat04; 
            }
        }
        return $Structor;
    }
    private function GenerateColumns($Structor) {
        if(isset($this->KolArr))
        {
            $Structor = $this->KolValLoop($Structor, "", ", ", "", "", $this->KolArr);
        }
        return $Structor;
    }
    private function GenerateValues($Structor) {
        if(isset($this->ValArr))
        {
            /*her skal der eventuelt ske noget validering som foregår i en anden funktion*/
            $Structor = $this->KolValLoop($Structor, "'", "', ", "'", "');", $this->ValArr);
        }
        return $Structor;
    }
    private function GenerateUpdateKolValPairs($Structor) {
        for($i = 0; $i < count($this->KolArr); $i++) 
        {
            if($i < count($this->KolArr) - 1)
            {
                $Structor = $Structor . $this->KolArr[$i];
                $Structor = $Structor . "=";
                $Structor = $Structor . "'" . $this->ValArr[$i] . "'" . ", ";
            }
            else 
            {
                $Structor = $Structor . $this->KolArr[$i];
                $Structor = $Structor . "=";
                $Structor = $Structor . "'" . $this->ValArr[$i] . "'";
            }
        }
        return $Structor;
    } 
    private function GenerateWhereStatement($Structor) {
        if(isset($this->ConKol, $this->ConVal))
        {
            $Structor = $Structor . $this->ConKol . "=" . "'" .$this->ConVal . "'";
        }
        else if(isset($this->ConKolArr, $this->ConValArr, $this->ConOps))
        {
            if($this->ValidateArrLengts($this->ConKolArr, $this->ConValArr))
            {
                for($i = 0; $i < count($this->ConKolArr); $i++)
                {
                    $Structor = $Structor . $this->ConKolArr[$i];
                    $Structor = $Structor . "=";
                    $Structor = $Structor . $this->ConValArr[$i];
                    if($this->ConOps[$i] == "||")
                    {
                        $Structor = $Structor . " OR ";
                    }
                    else if ($this->ConOps[$i] == "&&")
                    {
                        $Structor = $Structor . " AND ";
                    }
                }
            }
            else
            {
                $this->ErrorMsg = "Arrays with condition columns and condition values must be of same size";
            }
        }
        else 
        {
            $this->ErrorMsg = "wot";
        }
        return $Structor;
    }
    private function GenerateJoins($Structor) {
        if(isset($this->JoinTable, $this->JoinKol, $this->TableKol))
        {
            $Structor = $Structor . " INNER JOIN " . $this->JoinTable . " ON " . $this->JoinKol . "=" . $this->TableKol;  
        }
        else if(isset($this->JoinTables, $this->JoinKols, $this->TableKols))
        {
            for($i = 0; $i < count($this->JoinTables); $i++)
            {
            $Structor = $Structor . " INNER JOIN " . $this->JoinTables[$i] . " ON " . $this->JoinKols[$i] . "=" . $this->TableKols[$i];
            }
        }
        else
        {
            $this->ErrorMsg = "Gotta set a join or some joins";
        }
        return $Structor;
    }
    private function ConstructSelectFrom() {
        $Structor = "SELECT ";
        if(isset($this->KolArr))
        {
            $Structor = $this->GenerateColumns($Structor);
            $Structor = $Structor . " FROM " . $this->Table . ";";
        }
        else {
            $this->ErrorMsg = "You have not set any table columns";
        }
        return $Structor;
    }
    private function ConstructSelectFromWhere() {
        $Structor = "SELECT ";
        if(isset($this->KolArr))
        {
            $Structor = $this->GenerateColumns($Structor);
            $Structor = $Structor . " FROM " . $this->Table;
            $Structor = $Structor . " WHERE ";
            $Structor = $this->GenerateWhereStatement($Structor);
            $Structor = $Structor . ";";
        }
        else 
        {
            $this->ErrorMsg = "Either you have not set any table column to select, or you havent set any conditions, or both";
        }
        return $Structor;
    }
    private function ConstructSelectFromInnerJoin() {
        $Structor = "SELECT ";
        if(isset($this->KolArr))
        {
            $Structor = $this->GenerateColumns($Structor);
            $Structor = $Structor . " FROM " . $this->Table;
            $Structor = $this->GenerateJoins($Structor);
            $Structor = $Structor . ";";
        }
        else 
        {
            $this->ErrorMsg = "You have not even created columns yet";
        }
        return $Structor;
    }
    private function ConstructSelectFromInnerJoinWhere() {
        $Structor = "SELECT ";
        if(isset($this->KolArr))
        {
            $Structor = $this->GenerateColumns($Structor);
            $Structor = $Structor . " FROM " . $this->Table;
            $Structor = $this->GenerateJoins($Structor);
            $Structor = $Structor . " WHERE ";
            $Structor = $this->GenerateWhereStatement($Structor);
            $Structor = $Structor . ";";
        }
        else 
        {
            $this->ErrorMsg = "You have not even created columns yet";
        }
        return $Structor;
    }
    private function ConstructDelete() {
        $Structor = "DELETE FROM " . $this->Table . " WHERE ";
        $Structor = $this->GenerateWhereStatement($Structor);
        return $Structor;
    }
    private function ConstructUpdateSet() {
        $Structor = "UPDATE " . $this->Table . " SET ";
        if($this->ValidateArrLengts($this->KolArr, $this->ValArr))
        {
            $Structor = $this->GenerateUpdateKolValPairs($Structor);
            $Structor = $Structor . ";";
            return $Structor;
        }
        else 
        {
            return $this->ErrorMsg = "Array med kolonner og array med længde har forskellige længde";
        }
    }
    private function ConstructUpdateSetWhere() {
        $Structor = "UPDATE " . $this->Table . " SET ";
        if($this->ValidateArrLengts($this->KolArr, $this->ValArr)) 
        {
            $Structor = $this->GenerateUpdateKolValPairs($Structor);
            $Structor = $Structor . " WHERE ";
            $Structor = $this->GenerateWhereStatement($Structor);
            $Structor = $Structor . ";";
            return $Structor;
        }
        else 
        {
            return $this->ErrorMsg = "Array med kolonner og array med længde har forskellige længde";
        }
    }
    private function ConstructInsert() {
        $Structor = "INSERT INTO " . $this->Table . " (";
        if($this->ValidateArrLengts($this->KolArr, $this->ValArr))
        {
            $Structor = $this->GenerateColumns($Structor);
            $Structor = $Structor . ") VALUES (";
            $Structor = $this->GenerateValues($Structor);
            return $Structor;
        }
        else 
        {
            return $this->ErrorMsg = "Array med kolonner og array med længde har forskellige længde";
        }
    }
    public function SelectFrom($Con) {
        if(!isset($this->ErrorMsg))
        {    
            //echo $this->ConstructSelectFrom();
            $Result = mysqli_query($Con, $this->ConstructSelectFrom());
            return $Result;
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function SelectFromWhere($Con) {
        if(!isset($this->ErrorMsg))
        {
            //echo $this->ConstructSelectFromWhere();
            $Result = mysqli_query($Con, $this->ConstructSelectFromWhere());
            return $Result;
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function SelectFromInnerJoin($Con) {
        if(!isset($this->ErrorMsg))
        {
            //echo $this->ConstructSelectFromInnerJoin();
            $Result = mysqli_query($Con, $this->ConstructSelectFromInnerJoin());
            return $Result;
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function SelectFromInnerJoinWhere($Con) {
        if(!isset($this->ErrorMsg))
        {
          //  echo $this->ConstructSelectFromInnerJoinWhere();
            $Result = mysqli_query($Con, $this->ConstructSelectFromInnerJoinWhere());
            return $Result;
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function DeleteWhere($Con) {
        if(!isset($this->ErrorMsg))
        {
            mysqli_query($Con, $this->ConstructDelete());
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function UpdateSet($Con) {
        if(!isset($this->ErrorMsg))
        {
            mysqli_query($Con, $this->ConstructUpdateSet());
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function UpdateSetWhere($Con) {
        if(!isset($this->ErrorMsg))
        {
            mysqli_query($Con, $this->ConstructUpdateSetWhere());
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
    public function Insert($Con) {
        if(!isset($this->ErrorMsg))
        {
            mysqli_query($Con, $this->ConstructInsert());
            return $Con;
        }
        else 
        {
            echo $this->ErrorMsg;
        }
    }
}
<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST['LoggedIn'])) {
        header("Location: ../LoggedIn.php");
    }
    else if (isset($_POST['Indbakke'])) {
        header("Location: ../Indbakke.php");
    }
    else if (isset($_POST['Rediger'])) {
        header("Location: ../RedigerProfil.php");
    }
    else if (isset($_POST['Andre'])) {
        header("Location: ../AndreProfiler.php");
    }
    else if(isset($_POST['Gaestebog'])) {
        header("location: ../GaesteBog.php");
    }
    else if (isset($_POST['LogUd'])) {
        if (ini_get("session.use_cookies")) 
        {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
        }
        session_unset();
        $_SESSION = array();
        session_destroy();
        header("Location: ../index.php");
    }
}
?>
<div id="LoggedInMenuWrap">
    <form action="Includes/LoggedInMenu.php" method="POST">
    <input class="LoggedInBtn" type="submit" name="LoggedIn" value="Din Profil" />
    <input class="LoggedInBtn" type="submit" name="Indbakke" value="Din indbakke" />
    <input class="LoggedInBtn" type="submit" name="Rediger" value="Rediger profil" />
    <input class="LoggedInBtn" type="submit" name="Andre" value="Andre profiler" />
    <input class="LoggedInBtn" type="submit" name="Gaestebog" value="Gæstebog" />
    <input class="LoggedInBtn" type="submit" name="LogUd" value="Log ud" />
</form>
</div>
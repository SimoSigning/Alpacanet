<?php
include("Classes/Generals.php");
include("Classes/DataConnector.php");
include("Classes/DataBindings.php");
$SessionCheck = new Generals();
$SessionCheck->PublicPagesSessionCheck();

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST["KontaktSend"])) 
    {
        $connector = new DataConnector("localhost", "root", "", "alpacadb");
        $Emne = $_POST["EmneTxt"];
        $Besked = $_POST["Besked"];
        
        if(isset($_SESSION["BrugerID"])) 
        {
            $BrugerID = $_SESSION["BrugerID"];
            $Date = date('y-m-d H:i:s', time());
            
            $BeskedKols = array("BrugerID", "Tid");
            $BeskedVals = array($BrugerID, $Date);
            
            $opretBesked = new DataBindings("beskeder");
            $opretBesked->SetKols($BeskedKols);
            $opretBesked->SetVals($BeskedVals);
            
            $ConReturn = $opretBesked->Insert($connector->CreateCon());
            $LastId = mysqli_insert_id($ConReturn);
            if($LastId > 0) 
            {
                $SelectKols = array("Fornavn", "Email");
                $getKontaktData = new DataBindings("profiler");
                $getKontaktData->SetKols($SelectKols);
                $getKontaktData->SetCon("brugere.Id", 1);
                $getKontaktData->SetJoin("brugere", "brugere.Id", "profiler.BrugerID");
                $KontaktDataReturn = $getKontaktData->SelectFromInnerJoinWhere($connector->CreateCon());
                $ResultColumns = mysqli_fetch_assoc($KontaktDataReturn );
                $Navn = $ResultColumns["Fornavn"];
                $Email = $ResultColumns["Email"];
                
                $KontaktBeskedKols = array("BeskedID", "Navn", "Email", "Emne", "Besked");
                $KontaktBeskedVals = array($LastId, $Navn, $Email, $Emne, $Besked);
                $opretKontaktBesked = new DataBindings("kontaktbeskeder");
                $opretKontaktBesked->SetKols($KontaktBeskedKols);
                $opretKontaktBesked->SetVals($KontaktBeskedVals);
                $opretKontaktBesked->Insert($connector->CreateCon());
                $connector->DisableCon();
            }
        }
        else 
        {
            $Navn = $_POST["NavnTxt"];
            $Email = $_POST["EmailTxt"];
            $KontaktBeskedKols = array("Navn", "Email", "Emne", "Besked");
            $KontaktBeskedVals = array($Navn, $Email, $Emne, $Besked);
            $opretKontaktBesked = new DataBindings("kontaktbeskeder");
            $opretKontaktBesked->SetKols($KontaktBeskedKols);
            $opretKontaktBesked->SetVals($KontaktBeskedVals);
            $opretKontaktBesked->Insert($connector->CreateCon());
            $connector->DisableCon();
        }
    }
}
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #KontaktTable {
            width:50%;
            margin:auto;
            border-collapse:collapse;
        }
        #KontaktHead {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .KontaktMeta {
            background-color:rgba(173, 128, 84, 0.9);
            width:29%;
            padding-left: 1%;
        }
        .KontaktCont {
            background-color:rgba(255, 255, 255, 0.9);
            width:70%;
        }
        .TxtInput {
            width:100%;
        }
        #BeskedCont {
            background-color:rgba(255, 255, 255, 0.9);
            height:200px;
        }
        #BeskedTxt {
            width:100%;
            height:100%;
        }
        #BeskedFooter {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        #KontaktBtn {
            width:30%;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <form action="Kontakt.php" method="POST">
            <table id="KontaktTable">
                <tr>
                    <th id="KontaktHead" colspan="2"> Kontakt AlpacaNet</th>
                </tr>
                <?php 
                if(!isset($_SESSION["BrugerID"])) 
                {
                    echo "<tr>";
                    echo "<td class='KontaktMeta'>";
                    echo "Navn";
                    echo "</td>";
                    echo "<td class='KontaktCont'>";
                    echo "<input class='TxtInput' type='text' name='NavnTxt' />";
                    echo "</td>";
                    echo "</tr>";
                    echo "<tr>";
                    echo "<td class='KontaktMeta'>";
                    echo "Email";
                    echo "</td>";
                    echo "<td class='KontaktCont'>";
                    echo "<input class='TxtInput' type='text' name='EmailTxt' />";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
                <tr>
                    <td class="KontaktMeta">
                        Emne
                    </td>
                    <td class="KontaktCont">
                        <input class="TxtInput" type="text" name="EmneTxt" />
                    </td>
                </tr>
                <tr>
                    <td id="BeskedCont" colspan="2">
                        <textarea id="BeskedTxt" name="Besked">
                        </textarea>
                    </td>
                </tr>
                <tr>
                    <td id="BeskedFooter" colspan="2">
                        <input id="KontaktBtn" type="submit" name="KontaktSend" value="Send" />
                    </td>
                </tr>
            </table>
            </form>
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
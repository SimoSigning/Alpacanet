<?php 
        include("Classes/Generals.php");
        include("Classes/DataConnector.php");
        include("Classes/DataBindings.php");
        $SessionCheck = new Generals();
        $SessionCheck ->LoginPagesSessionCheck();
        
        $BrugerID = $_SESSION["BrugerID"];
        
        $connector = new DataConnector("localhost", "root", "", "alpacadb");
        $ProfilKols = array("Brugernavn", "Email", "Fornavn", "Efternavn", "Telefon");
        $profilViewer = new DataBindings("brugere");
        $profilViewer->SetKols($ProfilKols);
        $profilViewer->SetJoin("profiler", "profiler.BrugerID", "brugere.Id");
        $profilViewer->SetCon("brugere.Id", $BrugerID);
        $ReturnResult = $profilViewer->SelectFromInnerJoinWhere($connector->CreateCon());
        $UserRowResult = mysqli_fetch_assoc($ReturnResult);
        $connector->DisableCon();
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #LoggedInTable {
            margin:auto;
            width:60%;
            border-collapse:collapse;
        }
        #LoggedHeader {
            background-color: rgba(120, 89, 58, 0.7);
            padding-top:5px;
            padding-bottom:5px;
        }
        .loggedCont01 {
            background-color:rgba(173, 128, 84, 0.7);
            width:40%;
            
        }
        .LoggedCont02 {
            width:60%;
            background-color: rgba(255,255,255,0.7);
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <table id="LoggedInTable">
                <tr>
                    <th id="LoggedHeader" colspan="2"> 
                      Din Profil
                    </th>
                </tr>
                <tr>
                    <td class="LoggedCont01"> 
                        Brugernavn
                    </td>
                    <td class="LoggedCont02">
                    <?php 
                    echo $UserRowResult["Brugernavn"];
                    ?>
                    </td>
                </tr>
                <tr>
                    <td class="LoggedCont01">
                        Email
                    </td>
                    <td class="LoggedCont02">
                    <?php 
                    echo $UserRowResult["Email"];
                    ?>
                    </td>
                </tr>
                <tr>
                    <td class="LoggedCont01">
                        Fornavn
                    </td>
                    <td class="LoggedCont02">
                    <?php 
                    echo $UserRowResult["Fornavn"];
                    ?>
                    </td>
                </tr>
                <tr>
                    <td class="LoggedCont01">
                        Efternavn
                    </td>
                    <td class="LoggedCont02">
                    <?php 
                    echo $UserRowResult["Efternavn"];
                    ?>
                    </td>
                </tr>
                <tr>
                    <td class="LoggedCont01">
                        Telefon
                    </td>
                    <td class="LoggedCont02">
                    <?php 
                    echo $UserRowResult["Telefon"];
                    ?>
                    </td>
                </tr>
            </table>
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
<?php
include("Classes/Generals.php");
include("Classes/DataConnector.php");
include("Classes/DataBindings.php");

$SessionCheck = new Generals();
$SessionCheck->LoginPagesSessionCheck();

$connector = new DataConnector("localhost", "root", "", "alpacadb");
$BrugerID = $_SESSION["BrugerID"];

$GaesteKols = array("brugere.Brugernavn", "beskeder.Tid", "gaestebeskeder.Emne", "gaestebeskeder.Besked");
$JoinTables = array("beskeder", "gaestebeskeder");
$JoinKols = array("beskeder.BrugerID", "gaestebeskeder.BeskedID");
$TableKols = array("brugere.Id", "beskeder.Id");
$gaesteData = new DataBindings("brugere");
$gaesteData->SetKols($GaesteKols);
$gaesteData->SetJoins($JoinTables, $JoinKols, $TableKols);
$UserSet = $gaesteData->SelectFromInnerJoin($connector->CreateCon());
$counter = 0;
while($row = mysqli_fetch_assoc($UserSet))
{
$Brugernavn[$counter] = $row["Brugernavn"];
$Tid[$counter] = $row["Tid"];
$Emne[$counter] = $row["Emne"];
$Besked[$counter] = $row["Besked"];
$counter++;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST["submitbesked"])) {
        $Date = date('y-m-d H:i:s', time());
        $emne = $_POST["emne"];
        $besked = $_POST["besked"];
            
        $BeskedKols = array("BrugerID", "Tid");
        $BeskedVals = array($BrugerID, $Date);
            
        $opretBesked = new DataBindings("beskeder");
        $opretBesked->SetKols($BeskedKols);
        $opretBesked->SetVals($BeskedVals);
            
        $ConReturn = $opretBesked->Insert($connector->CreateCon());
        $LastId = mysqli_insert_id($ConReturn);
        if($LastId > 0) {
            $BeskedKols = array("BeskedID", "Emne", "Besked");
            $BeskedVals = array($LastId, $emne, $besked);
            $gaesteBeskedInsert = new DataBindings("gaestebeskeder");
            $gaesteBeskedInsert->SetKols($BeskedKols);
            $gaesteBeskedInsert->SetVals($BeskedVals);
            $gaesteBeskedInsert->Insert($connector->CreateCon());
            $connector->DisableCon();
            }
    }
}
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #GaesteFormularTable {
            margin:auto;
            width:50%;
            border-collapse:collapse;
        }
        #GaesteFormularHead {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .GaesteFormularMeta {
            background-color:rgba(173, 128, 84, 0.9);
            text-align:center;
        }
        .GaesteFormularCont {
            background-color: rgba(255, 255, 255, 0.9);
            text-align:center;
        }
        #GaesteEmneTxt {
            width:100%;
        }
        #GaesteBeskedTxt {
            width:100%;
            height:200px;
        }
        #GaesteFormularFooter {
            background-color:rgba(173, 128, 84, 0.9);
            text-align:center;
        }
        #GaesteBtn {
            width:50%;
        }
        #GaestebogTable {
            width:60%;
            margin:auto;
            border-collapse:collapse;
        }
        #GaestebogHeader {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .IndlaegHead01 {
            background-color:rgba(137, 102, 67, 0.9);
            text-align:left;
            padding-left:1%;
            padding-top: 5px;
            padding-bottom: 5px;
            width:49%;
        }
        .IndlaegHead02 {
            background-color:rgba(137, 102, 67, 0.9);
            text-align:right;
            padding-right:1%;
            padding-top:5px;
            padding-bottom:5px;
            width:49%;
        }
        .IndlaegHead03 {
            background-color:rgba(173, 128, 84, 0.9);
            width:99%;
            padding-left:1%;
            padding-top:5px;
            padding-bottom:5px;
        }
        .IndlaegCont {
            background-color: rgba(255, 255, 255, 0.9);
            width:99%;
            padding-left:1%;
            padding-top:5px;
            padding-bottom: 5px;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <div id="BeskedFormular">
                <br />
                <form action="GaesteBog.php" method="POST">
                <table id="GaesteFormularTable">
                    <tr>
                        <th id="GaesteFormularHead">
                            Skriv indlæg
                        </th>
                    </tr>
                    <tr>
                        <td class="GaesteFormularMeta">
                            Emne
                        </td>
                    </tr>
                    <tr>
                        <td class="GaesteFormularCont">
                            <input id="GaesteEmneTxt" type="text" name="emne" />
                        </td>
                    </tr>
                    <tr>
                        <td class="GaesteFormularMeta">
                            Besked
                        </td>
                    </tr>
                    <tr>
                        <td class="GaesteFormularCont">
                            <textarea id="GaesteBeskedTxt" name="besked">
                            </textarea>
                        </td>
                    </tr>
                    <tr>
                        <td id="GaesteFormularFooter">
                            <input id="GaesteBtn" type="submit" name="submitbesked" value="Indsæt besked" />
                        </td>
                    </tr>
                </table>
                </form>
            </div>
            <div id="BeskedContent">
                <br />
                <table id="GaestebogTable">
                    <tr>
                        <th id="GaestebogHeader" colspan="2">
                            Indlæg
                        </th>
                    </tr>
                 <?php
                 for($i = count($Brugernavn)-1; $i >= 0; $i--)
                 {
                     echo "<tr>";
                     echo "<td class='IndlaegHead01'>";
                     echo "<b>Skrevet af:</b> ". $Brugernavn[$i];
                     echo "</td>";
                     echo "<td class='IndlaegHead02'>";
                     echo "<b> Tidspunkt:</b>" . $Tid[$i];
                     echo "</td>";
                     echo "</tr>";
                     echo "<tr>";
                     echo "<td class='IndlaegHead03' colspan = '2'>";
                     echo "<b> Emne: </b>" . $Emne[$i];
                     echo "</td>";
                     echo "</tr>";
                     echo "<tr>";
                     echo "<td class='IndlaegCont' colspan='2'>";
                     echo $Besked[$i];
                     echo "</td>";
                     echo "</tr>";
                 }
                 ?>
                </table>
                <br />
            </div>
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
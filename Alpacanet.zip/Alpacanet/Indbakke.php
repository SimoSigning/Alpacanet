<?php 
        include("Classes/Generals.php");
        include("Classes/DataConnector.php");
        include("Classes/DataBindings.php");
        
        $SessionCheck = new Generals();
        $SessionCheck ->LoginPagesSessionCheck();
        
        $connector = new DataConnector("localhost", "root", "", "alpacadb");
        
        $BrugerID = $_SESSION["BrugerID"];
        
        $BeskedDataKols = array("brugere.Brugernavn", "privatbeskeder.BeskedID", "privatbeskeder.Emne", "privatbeskeder.Besked", "privatbeskeder.Laest");
        $BeskedDataConKols = array("brugere.Id", "privatbeskeder.Modtager");
        $BeskedDataConVals = array($BrugerID, "brugere.Brugernavn");
        $BeskedDataConOps = array("&&", "");
        $beskedData = new DataBindings("brugere, privatbeskeder");
        $beskedData->SetKols($BeskedDataKols);
        $beskedData->SetCons($BeskedDataConKols, $BeskedDataConVals, $BeskedDataConOps);
        $HapsBeskedData = $beskedData->SelectFromWhere($connector->CreateCon());
        $counter = 0;
        while($BeskedInfoRows = mysqli_fetch_assoc($HapsBeskedData))
        {
            $BeskedIDArr[$counter] = $BeskedInfoRows["BeskedID"];
            $EmneArr[$counter] = $BeskedInfoRows["Emne"];
            $BeskedArr[$counter] = $BeskedInfoRows["Besked"];
            $LaestArr[$counter] = $BeskedInfoRows["Laest"];
            $counter++;
        }
        if(isset($BeskedIDArr))
        {
            for($u = 0; $u < count($BeskedIDArr); $u++) 
            {
                $afsenderNavnTidArr = array("beskeder.BrugerID", "beskeder.Tid", "brugere.Brugernavn");
                $afsenderNavnTid = new DataBindings("beskeder");
                $afsenderNavnTid->SetKols($afsenderNavnTidArr);
                $afsenderNavnTid->SetJoin("brugere", "brugere.Id", "beskeder.BrugerID");
                $afsenderNavnTid->SetCon("beskeder.Id", $BeskedIDArr[$u]);
                $AfsenderNavnOgTidResult = $afsenderNavnTid->SelectFromInnerJoinWhere($connector->CreateCon());
                $AfsenderRows = mysqli_fetch_assoc($AfsenderNavnOgTidResult);
                $BrugerIDArr[$u] = $AfsenderRows["BrugerID"];
                $BrugerTidArr[$u] = $AfsenderRows["Tid"];
                $Brugernavne[$u] = $AfsenderRows["Brugernavn"];
            }
            $hmm = count($BrugerIDArr);
            $LaestEllerUlaest = array();
            for($u=0; $u < count($LaestArr); $u++) 
            {
                if($LaestArr[$u] == 0)
                {
                    $LaestEllerUlaest[$u] = "Ulæst";
                }
                else 
                {
                    $LaestEllerUlaest[$u] = "Læst";
                }
            }
        
            if($_SERVER['REQUEST_METHOD'] == 'POST') 
            {
                for($h = 0; $h < count($BrugerIDArr); $h++) 
                {
                    if(isset($_POST["sendsvar".$h.""]))
                    {
                        $Date = date('y-m-d H:i:s', time());

                        $BeskedKols = array("BrugerID", "Tid");
                        $BeskedVals = array($BrugerID, $Date);

                        $opretBesked = new DataBindings("beskeder");
                        $opretBesked->SetKols($BeskedKols);
                        $opretBesked->SetVals($BeskedVals);

                        $ConReturn = $opretBesked->Insert($connector->CreateCon());
                        $LastId = mysqli_insert_id($ConReturn);
                        if($LastId > 0) 
                        {
                            $Brugernavn = $Brugernavne[$h];
                            $SvarEmne = $_POST["emnesvarbesked"];
                            $Besked = $_POST["beskedsvar"];
                            $svarPrivatBesked = new DataBindings("privatbeskeder");
                            $PrivatBeskedKols = array("BeskedID", "Modtager", "Emne", "Besked");
                            $PrivatBeskedVals = array($LastId, $Brugernavn, $SvarEmne, $Besked);
                            $svarPrivatBesked->SetKols($PrivatBeskedKols);
                            $svarPrivatBesked->SetVals($PrivatBeskedVals);
                            $svarPrivatBesked->Insert($connector->CreateCon());
                        }
                    }
                    else if(isset($_POST["slet".$h.""])) 
                    {
                        $BeskedId = $BeskedIDArr[$h];
                        $deleteBesked = new DataBindings("privatbeskeder");
                        $deleteBesked->SetCon("BeskedID", $BeskedId);
                        $deleteBesked->DeleteWhere($connector->CreateCon());
                        header("Location: Indbakke.php");
                    }
                }
            } 
        }

?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #indbakkewrapper {
            width:90%;
            margin:auto;
        }
        #IndbakkeListe {
            width:100%;
        }
        #IndbakkeListeHeaders {
            width:100%;
        }
        #StatusOverskrift {
            background-color: rgba(120, 89, 58, 0.9);
            float:left;
            width:10%;
            font-weight:bold;
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        #BrugernavnOverskrift {
            background-color: rgba(120, 89, 58, 0.9);
            float:left;
            width:15%;
            font-weight:bold;
            padding-top:5px;
            padding-bottom:5px;
        }
        #TidOverskrift {
            background-color: rgba(120, 89, 58, 0.9);
            float:left;
            width:20%;
            font-weight:bold;
            padding-top:5px;
            padding-bottom:5px;
        }
        #EmneOverskrift {
            background-color: rgba(120, 89, 58, 0.9);
            float:left;
            width:15%;
            font-weight:bold;
            padding-top:5px;
            padding-bottom:5px;
        }
        .Knapoverskrift {
            background-color: rgba(120, 89, 58, 0.9);
            float:left;
            width:20%;
            font-weight:bold;
            padding-top:5px;
            padding-bottom:5px;
        }
        #IndbakkeListeContent {
            width:100%;
        }
        .IndbakkeLaestContent {
            background-color:rgba(173, 128, 84, 0.9);
            width:10%;
            height:20px;
            float:left;
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .IndbakkeBrugernavnContent {
            background-color:rgba(173, 128, 84, 0.9);
            width:15%;
            height:20px;
            float:left;
            padding-top:5px;
            padding-bottom:5px;
        }
        .IndbakkeTidContent {
            background-color:rgba(173, 128, 84, 0.9);
            width:20%;
            height:20px;
            float:left; 
            padding-top:5px;
            padding-bottom:5px;
        }
        .IndbakkeEmneContent {
            background-color:rgba(173, 128, 84, 0.9);
            width:15%;
            height:20px;
            float:left;
            padding-top:5px;
            padding-bottom:5px;
        }
        .IndbakkeKnapContent {
            background-color:rgba(173, 128, 84, 0.9);
            width:20%;
            height:20px;
            float:left;
            padding-top:5px;
            padding-bottom:5px;
        }
        #SeOgSvarHeader {
            background-color: rgba(120, 89, 58, 0.9);
            text-align:center;
            padding-top:5px;
            padding-bottom:5px;
        }
        #SeOgSvarWrapper {
            margin:auto;
            width:50%;
        }
        #SeEmne {
            background-color:rgba(173, 128, 84, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            padding-left:5px;
        }
        #SeBesked {
            background-color:rgba(255, 255, 255, 0.7);
        }
        #SvarBesked {
            background-color:rgba(173, 128, 84, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        #SvarBeskedBtn {
            width:50%;
        }
        #SendSvarBtn {
            width:50%;
        }
        #BeskedTxtfield {
            width:100%;
            height:200px;
        }
        #EmneSvarBesked {
            width:75%;
            float:right;
        }
        #BeskedEmneMeta {
            padding-top:5px;
            padding-bottom:5px;
            padding-left:5px;
        }
        #BeskedContainer {
            padding-top:5px;
            padding-bottom:5px;
            padding-left:5px;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <form action="Indbakke.php" method="POST">
                <div id="indbakkewrapper">
                    <div id="SeOgSvarWrapper">
                     <?php
                    if($_SERVER['REQUEST_METHOD'] == 'POST') 
                    {
                    echo "<div id='SeOgSvarHeader'>";
                    echo "Besked";
                    echo "</div>";
                    }
                    if($_SERVER['REQUEST_METHOD'] == 'POST') 
                    {
                    echo "<div id='SeEmne'>";
                        for($h = 0; $h < $hmm; $h++) 
                        {
                            if(isset($_POST["laes".$h.""]))
                            {
                                $emne = $EmneArr[$h];
                                echo "Emne: ".$emne."";
                            }
                            else if(isset($_POST["svarbesked".$h.""]))
                            {
                                echo "Emne: <input id='EmneSvarBesked' type='text' name='emnesvarbesked' />";
                            }
                        }
                    echo "</div>";
                    }
                    if($_SERVER['REQUEST_METHOD'] == 'POST') 
                    {
                    echo "<div id='SeBesked'>";
                        for($h = 0; $h < $hmm; $h++) 
                        {
                            if(isset($_POST["laes".$h.""]))
                            {
                                $beskedid = $BeskedIDArr[$h];
                                $laest = 1;
                                if($LaestArr[$h] == 0)
                                {
                                    $updateLaestKols = array("Laest");
                                    $updateLaestVals = array($laest);
                                    $updateLaest = new DataBindings("privatbeskeder");
                                    $updateLaest->SetKols($updateLaestKols);
                                    $updateLaest->SetVals($updateLaestVals);
                                    $updateLaest->SetCon("BeskedID", $beskedid);
                                    $updateLaest->UpdateSetWhere($connector->CreateCon());
                                }
                                    $besked = $BeskedArr[$h];
                                    echo "<div id='BeskedContainer'>";
                                    echo $besked;
                                    echo "</div>";
                                }
                                else if(isset($_POST["svarbesked".$h.""]))
                                {
                                echo "<textarea id='BeskedTxtField' name='beskedsvar'> </textarea>";
                                }
                        }
                    echo "</div>";
                    }
                    if($_SERVER['REQUEST_METHOD'] == 'POST')
                    {
                    echo "<div id='SvarBesked'>";
                        for($h = 0; $h < $hmm; $h++) 
                        {
                            if(isset($_POST["laes".$h.""]))
                            {
                                echo "<input id='SvarBeskedBtn' type='submit' name='svarbesked".$h."' value='Besvar' />";
                            }
                                else if(isset($_POST["svarbesked".$h.""]))
                            {
                                echo "<input id='SendSvarBtn' type='submit' name='sendsvar".$h."' value='Send svar' />";
                            }
                        }
                    echo "</div>";
                    }
                    ?>
                    </div>
                    <br />
                    <div id="IndbakkeListe">
                        <div id="IndbakkeListeHeaders">
                            <div id="StatusOverskrift">Status</div>
                            <div id="BrugernavnOverskrift">Brugernavn</div>
                            <div id="TidOverskrift">Tid</div>
                            <div id="EmneOverskrift">Emne</div>
                            <div class="Knapoverskrift">Slet</div>
                            <div class="Knapoverskrift">Se Besked</div>
                        </div>
                        <div id="IndbakkeListeContent">
                        <?php 
                        if(isset($BeskedIDArr))
                        {
                            for($p = count($BeskedIDArr)-1; $p >= 0; $p--)
                            {
                                echo "<div class='ListContentWrapper'>";
                                echo "<div class='IndbakkeLaestContent'>";
                                echo $LaestEllerUlaest[$p];
                                echo "</div>";
                                echo "<div class='IndbakkeBrugernavnContent'>";
                                echo $Brugernavne[$p];
                                echo "</div>";
                                echo "<div class='IndbakkeTidContent'>";
                                echo $BrugerTidArr[$p];
                                echo "</div>";
                                echo "<div class='IndbakkeEmneContent'>";
                                echo $EmneArr[$p];
                                echo "</div>";
                                echo "<div class='IndbakkeKnapContent'>";
                                echo "<input type='submit', value='Slet besked' name='slet".$p."' />";
                                echo "</div>";
                                echo "<div class='IndbakkeKnapContent'>";
                                echo " <input type='submit' onclick='myevent()' value='Se besked' name='laes".$p."' />";
                                echo "</div>";
                                echo "</div>";
                            }
                        }
                        else {
                            echo "Ingen beskeder";
                        }
                        ?>
                        </div>
                    </div>
                </div>
            </form>
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
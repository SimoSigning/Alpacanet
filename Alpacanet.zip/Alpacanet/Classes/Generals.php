<?php
class Generals {
    function PublicPagesSessionCheck() {
        session_start();
        if (!isset($_SESSION["BrugerID"])) 
        {
        session_abort();
        session_unset();
        }
    }
    function LoginPagesSessionCheck() {
        session_start();
        if($_SESSION["BrugerID"] == null)
        {
            header("Location: index.php");
        }
    }
}
?>

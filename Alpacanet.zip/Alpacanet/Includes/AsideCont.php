<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST['Login']))
    {   
        include '../Classes/DataBindings.php';
        include '../Classes/DataConnector.php';
        $brugernavn = $_POST['BrugerNavn'];
        $kodeord = $_POST['KodeOrd'];
        $brugernavn = "'" . $brugernavn . "'";
        $kodeord = "'" . $kodeord . "'";
        $connector = new DataConnector("localhost", "root", "", "alpacadb");
        $ValidateUserKol = array("Id");
        $ValidateUserKolCons = array("brugernavn", "password");
        $ValidateUserValCons = array($brugernavn, $kodeord);
        $ValidateUserConOps = array("&&", "");
        $userValiBinder = new DataBindings("brugere");
        $userValiBinder->SetKols($ValidateUserKol);
        $userValiBinder->SetCons($ValidateUserKolCons, $ValidateUserValCons, $ValidateUserConOps);
        $ValiReturnResult = $userValiBinder->SelectFromWhere($connector->CreateCon());
        $AffectedRows = mysqli_num_rows($ValiReturnResult);
        $RowResult = mysqli_fetch_assoc($ValiReturnResult);
        if($AffectedRows > 0)
        {
            session_start();
            $_SESSION["BrugerID"] = $RowResult["Id"];
            header("Location: ../LoggedIn.php");
        }
        else
        {
            header("Location: ../LoggedIn.php");;
        }
        mysqli_close($Con);
    }
    else if(isset($_POST['OpretSide']))
    {
    header("Location: ../Opret.php");
    }
}
?>
<aside>
    <br />
    <?php 
    if(isset($_SESSION["BrugerID"]))
    {
        include 'LoggedInMenu.php';
    }
    else {
        include 'LoginMenu.php';
    }
    ?>
    <br />
    <div id="AlpacaRightHeader">
      Alpaca
    </div>
    <div id="AlpacaRightContent">
      asdfsadfdsafas </br>
      gfdsgsdjhjjh </br>
      sgfjjkksdfgfsdsgfs </br>
      gfdsfdswerwe </br>
    </div>
</aside>
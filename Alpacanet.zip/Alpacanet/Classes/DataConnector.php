<?php
class DataConnector {

    private $ServerName;
    private $UserName;
    private $Password;
    private $DBName;
    
    function __construct($Server, $User, $Pass, $DB) {
        $this->SetServer($Server);
        $this->SetUser($User);
        $this->SetPass($Pass);
        $this->SetDB($DB);
    }
    private function SetServer($Server) 
    { 
        $this->ServerName = $Server;
    }
    private function SetUser($User) 
    {
        $this->UserName = $User;
    }
    private function SetPass($Pass) 
    {
        $this->Password = $Pass;
    }
    private function SetDB($DB) 
    {
        $this->DBName = $DB;
    }
    public function CreateCon() 
    {
       return mysqli_connect($this->ServerName, $this->UserName, $this->Password, $this->DBName);
    }
    public function DisableCon() 
    {
        mysqli_close($this->CreateCon());
    }
}
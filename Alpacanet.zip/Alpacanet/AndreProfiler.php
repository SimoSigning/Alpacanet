<?php 
        include("Classes/Generals.php");
        include("Classes/DataConnector.php");
        include("Classes/DataBindings.php");
        
        $SessionCheck = new Generals();
        $SessionCheck ->LoginPagesSessionCheck();
        
        $BrugerID = $_SESSION["BrugerID"];
        
        $connector = new DataConnector("localhost", "root", "", "alpacadb");
        $UserListKol = array("Brugernavn");
        $userListView = new DataBindings("brugere");
        $userListView->SetKols($UserListKol);
        $UserListReturn = $userListView->SelectFrom($connector->CreateCon());
        $UserListRows = mysqli_fetch_all($UserListReturn, MYSQLI_NUM);
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            if(isset($_POST['valgtbruger'])) 
            {
                $_SESSION["ValgtBruger"] = $_POST['Users'];
                $ValgtBruger = $_POST['Users'];
                $ViewBrugerKols = array("Brugernavn", "Email", "Fornavn", "Efternavn", "Telefon");
                $viewChosenUser = new DataBindings("brugere");
                $viewChosenUser->SetKols($ViewBrugerKols);
                $viewChosenUser->SetJoin("profiler", "profiler.BrugerID", "brugere.Id");
                $viewChosenUser->SetCon("Brugernavn", $ValgtBruger);
                $ReturnChosenUser = $viewChosenUser->SelectFromInnerJoinWhere($connector->CreateCon());
                $RowUserResult = mysqli_fetch_assoc($ReturnChosenUser);
            }
            else if(isset($_POST['SendBesked'])) 
            {
                if(isset($_SESSION["BrugerID"])) 
                {
                    $Emne = $_POST["EmneText"];
                    $Besked = $_POST["BeskedText"];
                    $ValgtBurger = $_SESSION["ValgtBruger"];
                    $BrugerID = $_SESSION["BrugerID"];
                    $Date = date('y-m-d H:i:s', time());
                    
                    $BeskedKols = array("BrugerID", "Tid");
                    $BeskedVals = array($BrugerID, $Date);
            
                    $opretBesked = new DataBindings("beskeder");
                    $opretBesked->SetKols($BeskedKols);
                    $opretBesked->SetVals($BeskedVals);
            
                    $ConReturn = $opretBesked->Insert($connector->CreateCon());
                    $LastId = mysqli_insert_id($ConReturn);
                    if($LastId > 0) 
                    {
                        $PrivatBeskedKols = array("BeskedID", "Modtager", "Emne", "Besked");
                        $PrivatBeskedVals = array($LastId, $ValgtBurger, $Emne, $Besked);
                        $opretPrivatBesked = new DataBindings("privatbeskeder");
                        $opretPrivatBesked->SetKols($PrivatBeskedKols);
                        $opretPrivatBesked->SetVals($PrivatBeskedVals);
                        $opretPrivatBesked->Insert($connector->CreateCon());
                    }
                }
            }
        }
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #ListBoxCont {
            float:left;
            width:40%;
            height:45%;
            text-align:center;
        }
        #ValgtBrugerDiv {
            float:left;
            width:60%;
            height:45%;
        }
        #SendBeskedDiv {
            float:left;
            width:100%;
            height:55%;
        }
        #ValgtBrugerTable {
            width:80%;
            margin:auto;
            border-collapse: collapse; 
        }
        #ValgtProfilHeader {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
        }
        #BrugerListTable {
            width:80%;
            margin:auto;
            border-collapse: collapse;
        }
        #BrugerListHeader {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
        }
        #BrugerListContent {
            background-color: rgba(255, 255, 255, 0.9);
        }
        #BrugerListFooter {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
        }
        #BrugerSelector {
            width:100%;
            height:100%;
        }
        #VaelgBrugerBtn {
            width:100%;
        }
        .ValgtBrugerMeta {
            background-color: rgba(173, 128, 84, 0.9);
            width:40%;
            font-weight:bold;
        }
        .ValgtBrugerCont {
            background-color: rgba(255, 255, 255, 0.9);
            width:60%;
        }
        #ValgtBrugerFooter {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        #PostBtn {
            width: 50%;
        }
        #SendPostTable {
        width:50%;
        margin:auto;
        border-collapse:collapse;
        }
        #BeskedHeader {
        background-color:rgba(120, 89, 58, 0.9);
        }
        #BeskedHead {
        text-align:center;
        font-weight:bold;
        padding-top:5px;
        padding-bottom:5px;
        }
        #BeskedContent {
        background-color:rgba(173, 128, 84, 0.9);
        }
        #BeskedFooter {
        background-color:rgba(120, 89, 58, 0.9);
        text-align:center;
        padding-top:5px;
        padding-bottom:5px;
        }
        #EmneMeta {
        background-color:rgba(173, 128, 84, 0.9);
        }
        #EmneCont {
        background-color:rgba(173, 128, 84, 0.9);
        }
        #EmneTxt {
            width:100%;
        }
        #BeskedCont {
        background-color:rgba(173, 128, 84, 0.9);
        }
        #BeskedTxt {
        width:100%;
        height:200px;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <div id="ListBoxCont">
                <br />
                <form action="AndreProfiler.php" method="POST">
                <table id="BrugerListTable"> 
                    <tr>
                        <th id="BrugerListHeader">
                            Vælg bruger
                        </th>
                    </tr>
                    <tr>
                        <td id="BrugerListContent">
                            <select id="BrugerSelector" name="Users" size="15">
                            <?php
                            foreach($UserListRows as $UserName) 
                            {
                              echo "<option value='".implode($UserName)."'>";
                              echo implode($UserName);
                              echo "</option>";
                            }       
                            ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td id="BrugerListFooter">
                          <input id="VaelgBrugerBtn" type="submit" name="valgtbruger" value="Vælg bruger" />   
                        </td>
                    </tr>
                </table>
                </form>   
            </div>
            <div id="ValgtBrugerDiv">
                <br />
             <table id="ValgtBrugerTable">
                <tr>
                   <th id="ValgtProfilHeader" colspan="2"> Bruger profil</th>
                </tr>
                <tr>
                    <td class="ValgtBrugerMeta">
                        Brugernavn:
                    </td>
                    <td class="ValgtBrugerCont">
                        <?php 
                        if($_SERVER['REQUEST_METHOD'] == 'POST')
                        {
                            if(isset($_POST['valgtbruger'])) {
                                echo $RowUserResult['Brugernavn'];
                            }
                        }
                        else 
                        {
                            echo "";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="ValgtBrugerMeta">
                        Email:
                    </td>
                    <td class="ValgtBrugerCont">
                        <?php 
                        if($_SERVER['REQUEST_METHOD'] == 'POST')
                        {
                            if(isset($_POST['valgtbruger'])) {
                               echo $RowUserResult['Email']; 
                            }
                            
                        }
                        else 
                        {
                            echo "";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="ValgtBrugerMeta">
                        Fornavn:
                    </td>
                    <td class="ValgtBrugerCont">
                        <?php 
                        if($_SERVER['REQUEST_METHOD'] == 'POST')
                        {
                            if(isset($_POST['valgtbruger'])) {
                              echo $RowUserResult['Fornavn']; 
                            }
                        }
                        else 
                        {
                            echo "";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="ValgtBrugerMeta">
                        Efternavn:
                    </td>
                    <td class="ValgtBrugerCont">
                        <?php 
                        if($_SERVER['REQUEST_METHOD'] == 'POST')
                        {
                            if(isset($_POST['valgtbruger']))  {
                               echo $RowUserResult['Efternavn']; 
                            }
                        }
                        else 
                        {
                            echo "";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="ValgtBrugerMeta">
                        Telefon:
                    </td>
                    <td class="ValgtBrugerCont">
                        <?php 
                        if($_SERVER['REQUEST_METHOD'] == 'POST')
                        {
                            if(isset($_POST['valgtbruger'])) {
                                echo $RowUserResult['Telefon'];
                            }
                        }
                        else 
                        {
                            echo "";
                        }
                        ?>
                    </td>
                </tr>
                <?php
                if($_SERVER['REQUEST_METHOD'] == 'POST')
                {
                echo "<form action='AndreProfiler.php' method='POST'>";
                echo "<tr>";
                echo "<td id='ValgtBrugerFooter' colspan='2'>";
                echo "<input id='PostBtn' type='button' onclick='GenerateSendContent()' name='sendpost' value='Send besked' />";
                echo "</td>";
                echo "</tr>";
                echo "</form>";
                }
                ?>
            </table>
            </div>
            <form action="AndreProfiler.php" method="POST">
            <div id="SendBeskedDiv">
            </div>
            </form>
                <script>
                function GenerateSendContent() {
                    document.getElementById("SendBeskedDiv").innerHTML = "";
                    var SendPostTable = document.createElement("TABLE");
                    SendPostTable.setAttribute("id", "SendPostTable");
                    document.getElementById("SendBeskedDiv").appendChild(SendPostTable);
                  /***********************HEADER*********************/
                    var HeaderRow = document.createElement("TR");
                    HeaderRow.setAttribute("id", "BeskedHeader");
                    document.getElementById("SendPostTable").appendChild(HeaderRow);

                    var HeaderCont = document.createElement("TD");
                    HeaderCont.setAttribute("colspan", 2);
                    HeaderCont.setAttribute("id", "BeskedHead");
                    var HeaderText = document.createTextNode("Send besked");
                    HeaderCont.appendChild(HeaderText);
                    document.getElementById("BeskedHeader").appendChild(HeaderCont);
                    /*****************************************/
                    /********************EMNE CONTENT********************/
                    var ContentEmneRow = document.createElement("TR");
                    ContentEmneRow.setAttribute("id", "EmneContent");
                    document.getElementById("SendPostTable").appendChild(ContentEmneRow);

                    var ContentEmneMeta = document.createElement("TD");
                    ContentEmneMeta.setAttribute("id", "EmneMeta");
                    var ContentEmneMetaText = document.createTextNode("Emne:");
                    ContentEmneMeta.appendChild(ContentEmneMetaText);
                    document.getElementById("EmneContent").appendChild(ContentEmneMeta);

                    var ContentEmneCont = document.createElement("TD");
                    ContentEmneCont.setAttribute("id", "EmneCont");
                    document.getElementById("EmneContent").appendChild(ContentEmneCont);

                    var ContentEmneTxt = document.createElement("input");
                    ContentEmneTxt.setAttribute("id", "EmneTxt");
                    ContentEmneTxt.setAttribute("type", "text");
                    ContentEmneTxt.setAttribute("name", "EmneText");
                    ContentEmneCont.appendChild(ContentEmneTxt);
                    /*******************BESKED CONTENT*****************************/
                    var ContentBeskedRow = document.createElement("TR");
                    ContentBeskedRow.setAttribute("id", "BeskedInput");
                    document.getElementById("SendPostTable").appendChild(ContentBeskedRow);

                    var ContentBeskedCont = document.createElement("TD");
                    ContentBeskedCont.setAttribute("id", "BeskedCont");
                    ContentBeskedCont.setAttribute("colspan", 2);
                    document.getElementById("BeskedInput").appendChild(ContentBeskedCont);

                    var ContentBeskedTxt = document.createElement("textarea");
                    ContentBeskedTxt.setAttribute("id", "BeskedTxt");
                    ContentBeskedTxt.setAttribute("name", "BeskedText");

                    ContentBeskedCont.appendChild(ContentBeskedTxt);

                    /******************FOOTER**********************/
                    var FooterRow = document.createElement("TR");
                    FooterRow.setAttribute("id", "BeskedFooter");
                    document.getElementById("SendPostTable").appendChild(FooterRow);

                    var FooterCont = document.createElement("TD");
                    FooterCont.setAttribute("colspan", 2);

                    var sendbutton = document.createElement("input");
                    sendbutton.setAttribute("id", "SendPostBtn");
                    sendbutton.setAttribute("type", "submit");
                    sendbutton.setAttribute("name", "SendBesked");
                    sendbutton.setAttribute("value", "Send");
                    FooterCont.appendChild(sendbutton);

                    document.getElementById("BeskedFooter").appendChild(FooterCont);
                   /*****************************************/
                  }
            </script>
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
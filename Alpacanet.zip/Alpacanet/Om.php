<?php 
include("Classes/Generals.php");
$SessionCheck = new Generals();
$SessionCheck->PublicPagesSessionCheck();

$tester = new Tester("host", "username", "pass", "alpacadb");
echo $tester;
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #OmAlpacaTable {
            width:70%;
            margin:auto;
            border-collapse:collapse;
        }
        #OmAlpacaHead {
            background-color:rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        #OmAlpacaCont {
            background-color:rgba(255, 255, 255, 0.5);
            padding-top:5px;
            padding-bottom:5px;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <table id="OmAlpacaTable">
                <tr>
                    <th id="OmAlpacaHead">
                        Om Alpacaen
                    </th>
                </tr>
                <tr>
                    <td id="OmAlpacaCont">
                        Alpakaen (Vicugna pacos) er et domestikeret sydamerikansk pattedyr i familien Camelidae. Den er nært beslægtet med den vildtlevende vikunja. Der er fremavlet to racer af alpakaen, suri og huacaya. Huacaya er den mest almindelige. 
                        Indtil 2001 var alpakaens videnskabelige betegnelse Lama pacos, idet man antog at den var nærmere beslægtet med lamaen, og ligesom denne nedstammede fra den vildtlevende guanaco. Nye DNA-teknologier har imidlertid afsløret at den nedstammer fra vikunjaen.[1] 
                        Alpakaer holdes hele året på græs i 3.500-5.000 meters højde i Andesbjergene, omkring 80 procent af dyrene findes i Peru.[2] Alpakaen er betydeligt mindre end lamaen og blev ikke avlet som pakdyr, men for dens uld. Alpakauld anvendes i strikkede eller vævede tekstiler som tæpper, sweatre, hatte, handsker, tørklæder, ponchos, frakker og sengetøj. 
                        En udvokset alpaka har normalt en højde på 81-99 cm og vejer 48-84 kg. 
                        -Wikipedia
                    </td>
                </tr>
            </table>

        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>

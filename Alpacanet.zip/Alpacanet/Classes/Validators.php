<?php
class Validator {
    //put your code here
}
?>

<?php
include("Classes/Generals.php");
$SessionCheck = new Generals();
$SessionCheck->PublicPagesSessionCheck();
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            Velkommen til AlpacaNet
            <br />
            Danmarks første hjemmeside dedikeret til Alpaca dyreracen. Her kan du oprette bruger og <br />
            se profiler på andre Alpaca entusiaster. Senere kommer der måske et forum hvor <br />
            man kan debatere Alpacaer.
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>

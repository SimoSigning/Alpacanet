<?php
include("Classes/Generals.php");
include("Classes/DataConnector.php");
include("Classes/DataBindings.php");

$SessionCheck = new Generals();
$SessionCheck->PublicPagesSessionCheck();

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST["OpretBruger"])) 
    {
        $Brugernavn = $_POST['Brugernavn'];
        $Kodeord = $_POST['Password'];
        $Email = $_POST['Email'];
        
        $connection = new DataConnector("localhost", "root", "", "alpacadb");
        
        $BrugernavnKols = array("Brugernavn");
        $validateUser = new DataBindings("brugere");
        $validateUser->SetKols($BrugernavnKols);
        $validateUser->SetCon("Brugernavn", $Brugernavn);
        $ValidateUserReturn = $validateUser->SelectFromWhere($connection->CreateCon());
        $UserReturn = mysqli_fetch_assoc($ValidateUserReturn);
        if($UserReturn == "")
        {
            $BrugerKol = array("Brugernavn", "Password", "Email");
            $BrugerVal = array($Brugernavn, $Kodeord, $Email);

            $opretBruger = new DataBindings("brugere");
            $opretBruger->SetKols($BrugerKol);
            $opretBruger->SetVals($BrugerVal);
            $ConReturn = $opretBruger->Insert($connection->CreateCon());
            $LastId = mysqli_insert_id($ConReturn);
            if($LastId > 0)
            {
                $ProfilKol = array("BrugerID", "Fornavn", "Efternavn", "Telefon");
                $ProfilVal = array($LastId, "Fornavn", "Efternavn", "Telefon");
                $opretProfil = new DataBindings("profiler");
                $opretProfil->SetKols($ProfilKol);
                $opretProfil->SetVals($ProfilVal);
                $opretProfil->Insert($connection->CreateCon());
                header("Location: index.php");
            }
        }
        else 
        {
            $OptagetBesked = "Brugernavnet " . $Brugernavn .  " er allerede optaget";
        }
    }
}
?>
<html>
<head>
    <title> AlpacaNet </title>
    <link href="Styles/AlpacaStyles.css" rel="stylesheet" type="text/css"/>
    <style>
        #OpretTable {
            margin:auto;
            width:50%;
            border-collapse:collapse;
        }
        #OpretHeader {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            font-weight:bold;
        }
        .OpretMeta {
            background-color: rgba(173, 128, 84, 0.9);
            font-weight:bold;
            width:35%;
        }
        .OpretField {
            background-color: rgba(255, 255, 255, 0.9);
            width:65%;
        }
        #OpretFooter {
            background-color: rgba(120, 89, 58, 0.9);
            padding-top:5px;
            padding-bottom:5px;
            text-align:center;
        }
        .OpretTxt {
            width:60%;
        }
        #OpretSubmit {
            width:40%;
        }
    </style>
</head>
<body>
  <div id="PageWrapper">
  <?php include 'Includes/TopCont.php';?>
  <main>
    <div id="maincontent">
        <div id="mainleft">
            <br />
            <?php include 'Includes/VideoContent.php';?>
        </div>
        <div id="mainright">
            <form action="Opret.php" method="POST">
            <table id="OpretTable">
                <tr>
                    <th id="OpretHeader" colspan="2">
                        Opret bruger
                    </th>
                </tr>
                <tr>
                    <td class="OpretMeta">
                        Brugernavn:
                    </td>
                    <td class="OpretField">
                         <input class="OpretTxt" type="text" name="Brugernavn" />
                    </td>
                </tr>
                <tr>
                    <td class="OpretMeta">
                        Password:
                    </td>
                    <td class="OpretField">
                        <input class="OpretTxt" type="password" name="Password" />
                    </td>
                </tr>
                <tr>
                    <td class="OpretMeta">
                        Email:
                    </td>
                    <td class="OpretField">
                        <input class="OpretTxt" type="text" name="Email" />
                    </td>
                </tr>
                <tr>
                    <td id="OpretFooter" colspan="2">
                        <?php 
                        if(isset($OptagetBesked))
                        {
                            echo $OptagetBesked;
                            echo "<br>";
                        }
                        ?>
                        <input id="OpretSubmit" type="submit" value="Opret" name="OpretBruger" />
                    </td>
                </tr>
            </table>
            </form>            
        </div>
     </div>
  <?php include 'Includes/AsideCont.php'; ?>
   </main>
  <?php include 'Includes/BottomCont.php'; ?>
  </div>
</body>
</html>
  <header>
    <div id="AlpacaLogo"> 
        Alpacanet 
    </div>
   </header>
  <nav>
      <div class="MenuDiv">
          <a class='MainMenuLinks' href='index.php'>
          Forside 
          </a>
      </div>
      <div class="MenuDiv">
          <a class='MainMenuLinks' href='Om.php'>
          Om 
          </a>
      </div>
      <div class="MenuDiv">
        <a class='MainMenuLinks' href='Galleri.php'>
          Galleri
        </a>
       </div>
      <div class="MenuDiv">
        <a class='MainMenuLinks' href='Kontakt.php'>
          Kontakt
        </a>
      </div>
  </nav>
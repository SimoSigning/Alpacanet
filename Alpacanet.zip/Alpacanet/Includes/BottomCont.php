    <footer> 
        <div id="FooterContent">
           copyright (c) Alpacanet 
        </div>
    </footer>

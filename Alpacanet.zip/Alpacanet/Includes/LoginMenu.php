    <form method="POST" action="Includes/AsideCont.php">
      <div id="LoginHeader">
        Login
      </div>
      <div id="LoginContent">
            <input id="TxtInput01" type="text" name="BrugerNavn"/>
            <input id="TxtInput02" type="password" name="KodeOrd"/>
      </div>
      <div id="LoginFooter">
            <input class="LoginBtns" type="submit" value="Login" name="Login" />
            <input class="LoginBtns" type="submit" value="Opret" name="OpretSide" />
      </div>
    </form>